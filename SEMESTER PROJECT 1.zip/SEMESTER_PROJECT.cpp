#include <iostream>
#include <string>
#include <vector>


//AMOAH AUGUSTA 
//UEB3220522

class Product {
public:
    Product(const std::string& name, double price, int quantity)
        : name(name), price(price), quantity(quantity) {}

    void displayDetails() const {
        std::cout << "Name: " << name << "\nPrice: $" << price << "\nQuantity: " << quantity << "\n";
    }

    void updateDetails(double newPrice, int newQuantity) {
        price = newPrice;
        quantity = newQuantity;
    }

    double getPrice() const {
        return price;
    }

    std::string getName() const {
        return name;
    }

private:
    std::string name;
    double price;
    int quantity;
};

int main() {
    std::vector<Product> inventory;

    while (true) {
        std::cout << "Select an option:\n";
        std::cout << "1. Buy\n";
        std::cout << "2. Add item\n";
        std::cout << "3. Update item details\n";
        std::cout << "4. Display items\n";
        std::cout << "5. Exit\n";

        int choice;
        std::cin >> choice;

        if (choice == 1) {
            std::string itemName;
            std::cout << "Enter the item name: ";
            std::cin >> itemName;

            for (std::vector<Product>::iterator it = inventory.begin(); it != inventory.end(); ++it) {
                if (it->getName() == itemName) {
                    double itemPrice = it->getPrice();
                    std::cout << "Item '" << itemName << "' bought successfully. Price: $" << itemPrice << "\n";
                    break;
                }
            }
        } else if (choice == 2) {
            std::string itemName;
            double itemPrice;
            int itemQuantity;

            std::cout << "Enter item name: ";
            std::cin >> itemName;
            std::cout << "Enter item price: ";
            std::cin >> itemPrice;
            std::cout << "Enter item quantity: ";
            std::cin >> itemQuantity;

            inventory.push_back(Product(itemName, itemPrice, itemQuantity));
            std::cout << "Item added successfully!\n";
        } else if (choice == 3) {
            std::string itemName;
            std::cout << "Enter the item name: ";
            std::cin >> itemName;

            for (std::vector<Product>::iterator it = inventory.begin(); it != inventory.end(); ++it) {
                if (it->getName() == itemName) {
                    double newPrice;
                    int newQuantity;

                    std::cout << "Enter new price: ";
                    std::cin >> newPrice;
                    std::cout << "Enter new quantity: ";
                    std::cin >> newQuantity;

                    it->updateDetails(newPrice, newQuantity);
                    std::cout << "Item details updated successfully!\n";
                    break;
                }
            }
        } else if (choice == 4) {
            std::cout << "Inventory:\n";
            for (std::vector<Product>::const_iterator it = inventory.begin(); it != inventory.end(); ++it) {
                it->displayDetails();
            }
        } else if (choice == 5) {
            std::cout << "Exiting the program.\n";
            break;
        } else {
            std::cout << "Invalid choice. Please select a valid option.\n";
        }
    }

    return 0;
}

